package org.tabooproject.reflex

@Target(AnnotationTarget.CLASS, AnnotationTarget.FILE)
annotation class Internal
