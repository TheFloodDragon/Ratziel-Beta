package cn.fd.ratziel.core.unuse.task.api

/**
 * Task - 任务
 *
 * @author TheFloodDragon
 * @since 2023/9/9 20:27
 */
interface Task {

    /**
     * 任务ID
     */
    val id: String

}