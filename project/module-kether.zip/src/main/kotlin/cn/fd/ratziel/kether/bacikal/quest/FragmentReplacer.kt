package cn.fd.ratziel.kether.bacikal.quest

/**
 * @author Lanscarlos
 * @since 2023-08-21 21:16
 */
class FragmentReplacer : BacikalQuestTransfer {

    override val name = "fragment-replacer"

    override fun transfer(source: StringBuilder) {
    }
}