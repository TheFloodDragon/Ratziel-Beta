package cn.fd.ratziel.kether.bacikal.parser

/**
 * @author Lanscarlos
 * @since 2023-08-25 00:59
 */
annotation class BacikalParser(val id: String)
