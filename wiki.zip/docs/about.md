---
title: 关于
sidebar_position: 1
---

# 介绍

基于Taboolib开发的一个多功能插件。

## 功能

+ 物品引擎